#!/system/bin/sh
# 由 KernelSU 在开机 late_start 阶段以 root 执行。
# 只做三件事：等开机完成 → 把 agent 放进 Termux 家目录 → 循环守护它。
MODDIR=${0%/*}

TERMUX=/data/data/com.termux/files
export HOME=$TERMUX/home
export PREFIX=$TERMUX/usr
export PATH=$PREFIX/bin:/system/bin:/system/xbin:/sbin
export LD_LIBRARY_PATH=$PREFIX/lib
BASH=$PREFIX/bin/bash
AGENT=$HOME/dsh-agent.sh
LOG=$HOME/dsh-agent.log

# 等系统起来（最多 5 分钟）
i=0
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
  i=$((i + 1))
  [ $i -gt 150 ] && exit 0
done
sleep 8

# Termux 没装或 bash 不在，就什么都不做（不碰系统）
[ -x "$BASH" ] || exit 0

# 安装/更新 agent（模块自带的那份）
if [ -f "$MODDIR/agent.sh" ]; then
  cp -f "$MODDIR/agent.sh" "$AGENT" 2>/dev/null
  chmod 700 "$AGENT" 2>/dev/null
fi
[ -f "$AGENT" ] || exit 0

# 日志超过 1MB 就清空，防止无限增长
if [ -f "$LOG" ] && [ "$(wc -c < "$LOG" 2>/dev/null)" -gt 1048576 ]; then
  : > "$LOG" 2>/dev/null
fi

# 先干掉可能残留的旧实例
pkill -f "dsh-agent.sh" 2>/dev/null
sleep 1

# 守护循环：崩了 15 秒后重来
while true; do
  "$BASH" "$AGENT" >> "$LOG" 2>&1
  sleep 15
done &

﻿#!/data/data/com.termux/files/usr/bin/bash
# DSH 鎵嬫満鎵ц鍣?v7锛氱鍚嶆牎楠?+ 鍙敤 Termux 鐨?curl锛堜笉姹℃煋绯荤粺浜岃繘鍒讹級
T="<YOUR_NTFY_TOPIC>"
BASE="https://ntfy.sh"
KEY="<YOUR_HMAC_KEY>"
export PREFIX=/data/data/com.termux/files/usr
LOG="$HOME/dsh-agent.log"
# 娉ㄦ剰锛氳繖閲屾晠鎰忎笉璁剧疆 LD_LIBRARY_PATH 鈥斺€?鍚﹀垯 screencap 绛夌郴缁熺▼搴忎細鍔犺浇
# Termux 鐨勫悓鍚嶅簱鑰屽穿鎺夈€傚彧鍦ㄨ皟鐢?Termux 鐨?curl 鏃朵复鏃跺姞銆?curl_t() { env LD_LIBRARY_PATH="$PREFIX/lib" "$PREFIX/bin/curl" "$@"; }

# 鍗曞疄渚嬮攣
LOCK="$HOME/dsh-agent.lock"
if [ -f "$LOCK" ]; then
  OLD=$(cat "$LOCK" 2>/dev/null)
  if [ -n "$OLD" ] && kill -0 "$OLD" 2>/dev/null; then
    echo "[dsh-agent] 宸叉湁瀹炰緥鍦ㄨ窇锛圥ID $OLD锛夛紝鏈疄渚嬮€€鍑?
    exit 0
  fi
fi
echo $$ > "$LOCK"

echo "[dsh-agent] $(date '+%F %T') 宸插惎鍔紝绛夊緟鎸囦护鈥? | tee -a "$LOG"

getv() { printf '%s' "$MSG" | sed -n "s/.*\"$1\":\"\{0,1\}\([^\",}]*\)\"\{0,1\}.*/\1/p"; }

while true; do
  curl_t -s --no-buffer "$BASE/$T-cmd/json" 2>/dev/null | while IFS= read -r line; do
    case "$line" in *'"event":"message"'*) ;; *) continue;; esac
    RAW=$(printf '%s' "$line" | sed -n 's/.*"message":"\(.*\)"}$/\1/p')
    MSG=$(printf '%s' "$RAW" | sed 's/\\"/"/g')
    P=$(getv p)
    SIG=$(getv sig)
    [ -n "$P" ] && [ -n "$SIG" ] || continue
    EXPECT=$(printf '%s' "$P$KEY" | sha256sum | cut -d' ' -f1)
    if [ "$SIG" != "$EXPECT" ]; then
      echo "[dsh-agent] $(date '+%T') 绛惧悕涓嶅尮閰嶏紝涓㈠純" >> "$LOG"
      continue
    fi
    MSG=$(printf '%s' "$P" | base64 -d 2>/dev/null)
    ID=$(getv id)
    TOOL=$(getv tool)
    TS=$(getv ts)
    NOW=$(date +%s)
    if [ -n "$TS" ] && [ $((NOW - TS)) -gt 300 ]; then
      curl_t -s -m 10 -d "$ID|EXPIRED" "$BASE/$T-res" >/dev/null 2>&1
      continue
    fi
    OUT=""
    case "$TOOL" in
      alarm)
        H=$(getv hour); M=$(getv minute); L=$(getv label)
        timeout 8 am start -a android.intent.action.SET_ALARM \
          --ei android.intent.extra.alarm.HOUR "$H" \
          --ei android.intent.extra.alarm.MINUTES "$M" \
          --es android.intent.extra.alarm.MESSAGE "${L:-闂归挓}" \
          --ez android.intent.extra.alarm.SKIP_UI true </dev/null >/dev/null 2>&1 \
          && OUT="OK 宸茶闂归挓 $H:$M ${L}" || OUT="FAIL alarm";;
      nav)
        Q=$(getv q); QE=$(getv q_enc)
        [ -n "$QE" ] || QE="$Q"
        if timeout 8 am start -a android.intent.action.VIEW \
             -d "baidumap://map/direction?destination=$QE&mode=driving&src=andr.dsh.agent" \
             </dev/null >/dev/null 2>&1
        then OUT="OK 鐧惧害鍦板浘瀵艰埅锛?Q"
        elif timeout 8 am start -a android.intent.action.VIEW -d "geo:0,0?q=$Q" </dev/null >/dev/null 2>&1
        then OUT="OK 宸叉墦寮€瀵艰埅锛堢郴缁熼€夋嫨锛夛細$Q"
        else OUT="FAIL nav"; fi;;
      open)
        P2=$(getv pkg)
        C=$(cmd package resolve-activity --brief "$P2" 2>/dev/null | tail -n 1)
        if [ -n "$C" ] && timeout 8 am start -n "$C" </dev/null >/dev/null 2>&1
        then OUT="OK 宸叉墦寮€ $P2"
        elif timeout 8 monkey -p "$P2" -c android.intent.category.LAUNCHER 1 </dev/null >/dev/null 2>&1
        then OUT="OK 宸叉墦寮€ $P2 (monkey)"
        else OUT="FAIL open $P2"; fi;;
      tap)
        X=$(getv x); Y=$(getv y)
        timeout 8 input tap "$X" "$Y" </dev/null >/dev/null 2>&1 && OUT="OK 鐐瑰嚮 $X,$Y" || OUT="FAIL tap";;
      text)
        S=$(getv s)
        timeout 8 input text "$S" </dev/null >/dev/null 2>&1 && OUT="OK 宸茶緭鍏? || OUT="FAIL text";;
      key)
        K=$(getv k)
        timeout 8 input keyevent "$K" </dev/null >/dev/null 2>&1 && OUT="OK 鎸夐敭 $K" || OUT="FAIL key";;
      shot)
        F="$HOME/dsh-shot.png"
        rm -f "$F"
        # 蹇呴』鐢ㄥ共鍑€鐜锛歍ermux 鐨勭幆澧冧細璁?system 鐨?screencap 閾炬帴鍒伴敊璇殑搴?        timeout 10 env -i /system/bin/screencap -p "$F" </dev/null >/dev/null 2>&1
        if [ -s "$F" ]; then          curl_t -s -T "$F" -H "Filename: dsh-shot.png" -H "Message: $ID|shot" "$BASE/$T-res" >/dev/null 2>&1
          OUT="OK 鎴浘宸插洖浼?
        else OUT="FAIL shot"; fi;;
      shell)
        C=$(getv cmd); OUT=$(timeout 15 sh -c "$C" 2>&1 </dev/null | head -c 1500);;
      shell_b64)
        C=$(getv cmd_b64); C=$(printf '%s' "$C" | base64 -d 2>/dev/null); OUT=$(timeout 15 sh -c "$C" 2>&1 </dev/null | head -c 1500);;
      root)
        C=$(getv cmd)
        if [ "$(id -u)" = "0" ]; then OUT=$(timeout 15 sh -c "$C" 2>&1 </dev/null | head -c 1500); else OUT=$(timeout 15 su -c "$C" 2>&1 </dev/null | head -c 1500); fi;;
      root_b64)
        C=$(getv cmd_b64); C=$(printf '%s' "$C" | base64 -d 2>/dev/null)
        if [ "$(id -u)" = "0" ]; then OUT=$(timeout 15 sh -c "$C" 2>&1 </dev/null | head -c 1500); else OUT=$(timeout 15 su -c "$C" 2>&1 </dev/null | head -c 1500); fi;;
      ui_dump)
        U=/data/local/tmp/dsh-ui.xml
        rm -f "$U"
        timeout 20 su -Z u:r:shell:s0 2000 -c "/system/bin/uiautomator dump --compressed $U" >/dev/null 2>&1
        if [ -s "$U" ]; then
          curl_t -s -T "$U" -H "Filename: ui.xml" -H "Message: $ID|ui" "$BASE/$T-res" >/dev/null 2>&1
          OUT="OK 鐣岄潰宸插洖浼?
        else OUT="FAIL ui_dump"; fi;;
      ping)
        OUT="pong $(date +%H:%M:%S)";;
      notify)
        OUT=$(/system/bin/dumpsys notification --noredact 2>/dev/null | grep -E 'android\.title=|android\.text=' | sed 's/^ *//' | head -40 | tr '\n' ';');;
      bright)
        V=$(getv v)
        if [ -n "$V" ]; then
          /system/bin/settings put system screen_brightness "$V" >/dev/null 2>&1 && OUT="OK 浜害宸茶涓?$V" || OUT="FAIL bright"
        else OUT="褰撳墠浜害=$(/system/bin/settings get system screen_brightness 2>/dev/null)"; fi;;
      wifi)
        S=$(getv state); [ "$S" = "off" ] && S=disable || S=enable
        /system/bin/svc wifi "$S" 2>/dev/null && OUT="OK wifi $S" || OUT="FAIL wifi";;
      bt)
        S=$(getv state); [ "$S" = "off" ] && S=disable || S=enable
        /system/bin/svc bluetooth "$S" 2>/dev/null && OUT="OK bt $S" || OUT="FAIL bt";;
      dnd)
        S=$(getv state); [ "$S" = "off" ] && V=0 || V=1
        /system/bin/settings put global zen_mode "$V" >/dev/null 2>&1 && OUT="OK 鍕挎壈=$V" || OUT="FAIL dnd";;
      airplane)
        S=$(getv state); [ "$S" = "off" ] && V=0 || V=1
        /system/bin/settings put global airplane_mode_on "$V" >/dev/null 2>&1
        /system/bin/am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true >/dev/null 2>&1
        OUT="OK 椋炶妯″紡=$V";;
      swipe)
        X1=$(getv x1); Y1=$(getv y1); X2=$(getv x2); Y2=$(getv y2); D=$(getv ms)
        OUT="FAIL swipe"
        for _try in 1 2; do
          if timeout 8 input swipe "$X1" "$Y1" "$X2" "$Y2" "${D:-300}" </dev/null >/dev/null 2>&1; then
            OUT="OK swipe $X1,$Y1 -> $X2,$Y2"; break
          fi
          sleep 0.4
        done;;
      back)
        timeout 5 input keyevent 4 </dev/null >/dev/null 2>&1 && OUT="OK back" || OUT="FAIL back";;
      home)
        timeout 5 input keyevent 3 </dev/null >/dev/null 2>&1 && OUT="OK home" || OUT="FAIL home";;
      recents)
        timeout 5 input keyevent 187 </dev/null >/dev/null 2>&1 && OUT="OK recents" || OUT="FAIL recents";;
      camera)
        timeout 8 am start -a android.media.action.STILL_IMAGE_CAMERA </dev/null >/dev/null 2>&1 && OUT="OK 宸叉墦寮€鐩告満" || OUT="FAIL camera";;
      call)
        N=$(getv number)
        timeout 8 am start -a android.intent.action.CALL -d "tel:$N" </dev/null >/dev/null 2>&1 && OUT="OK 鎷ㄥ彿 $N" || OUT="FAIL call";;
      *)
        OUT="UNKNOWN tool: $TOOL";;
    esac
    curl_t -s -m 10 -d "$ID|$OUT" "$BASE/$T-res" >/dev/null 2>&1
    echo "[dsh-agent] $(date '+%T') $TOOL -> ${OUT:0:60}" >> "$LOG"
  done
  sleep 2
done

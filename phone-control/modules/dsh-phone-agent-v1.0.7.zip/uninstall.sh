#!/system/bin/sh
# 卸载模块时执行：停掉 agent 进程（不删 Termux 里的文件，避免动用户数据）
pkill -f "dsh-agent.sh" 2>/dev/null
exit 0
